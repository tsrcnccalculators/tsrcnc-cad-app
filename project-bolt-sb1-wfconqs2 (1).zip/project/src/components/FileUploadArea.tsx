import React, { useCallback, useState } from 'react';
import { Upload, FileText, AlertCircle, Ruler } from 'lucide-react';

interface FileUploadAreaProps {
  onFileUpload: (file: File) => void;
}

const FileUploadArea: React.FC<FileUploadAreaProps> = ({ onFileUpload }) => {
  const [dragActive, setDragActive] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    setUploadError(null);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      validateAndUpload(file);
    }
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError(null);
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      validateAndUpload(file);
    }
  };

  const validateAndUpload = (file: File) => {
    const allowedExtensions = ['.dwg', '.dxf'];
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!allowedExtensions.includes(fileExtension)) {
      setUploadError('Please upload a valid CAD file (.dwg or .dxf)');
      return;
    }

    if (file.size > 50 * 1024 * 1024) { // 50MB limit
      setUploadError('File size must be less than 50MB');
      return;
    }

    onFileUpload(file);
  };

  return (
    <div className="h-full flex items-center justify-center p-8">
      <div className="max-w-2xl w-full">
        <div
          className={`
            relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300
            ${dragActive 
              ? 'border-blue-500 bg-blue-500/10 scale-105' 
              : 'border-slate-600 hover:border-slate-500'
            }
          `}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <div className="flex flex-col items-center space-y-6">
            <div className="relative">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                <Upload className="w-12 h-12 text-white" />
              </div>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <FileText className="w-4 h-4 text-white" />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-white">Upload CAD Drawing</h3>
              <p className="text-slate-400 max-w-md">
                Drag and drop your DWG or DXF files here, or click to browse and select files from your computer.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <label className="cursor-pointer">
                <input
                  type="file"
                  className="hidden"
                  accept=".dwg,.dxf"
                  onChange={handleFileInput}
                />
                <div className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors duration-200 flex items-center space-x-2">
                  <Upload className="w-5 h-5" />
                  <span>Choose File</span>
                </div>
              </label>

              <div className="text-sm text-slate-500">
                Supported formats: .dwg, .dxf (max 50MB)
              </div>
            </div>

            {uploadError && (
              <div className="flex items-center space-x-2 text-red-400 bg-red-400/10 px-4 py-2 rounded-lg">
                <AlertCircle className="w-5 h-5" />
                <span>{uploadError}</span>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
            <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4">
              <Ruler className="w-6 h-6 text-blue-500" />
            </div>
            <h4 className="font-semibold text-white mb-2">Precise Measurements</h4>
            <p className="text-sm text-slate-400">
              Measure distances, angles, and areas with professional accuracy.
            </p>
          </div>

          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
            <div className="w-12 h-12 bg-orange-500/10 rounded-lg flex items-center justify-center mb-4">
              <FileText className="w-6 h-6 text-orange-500" />
            </div>
            <h4 className="font-semibold text-white mb-2">Multiple Formats</h4>
            <p className="text-sm text-slate-400">
              Support for DWG and DXF files from all major CAD software.
            </p>
          </div>

          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
            <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center mb-4">
              <Upload className="w-6 h-6 text-green-500" />
            </div>
            <h4 className="font-semibold text-white mb-2">No Software Required</h4>
            <p className="text-sm text-slate-400">
              View and analyze your drawings directly in your web browser.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FileUploadArea;