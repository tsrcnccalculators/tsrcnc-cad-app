import React from 'react';
import { 
  MousePointer, 
  Move, 
  Ruler, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Grid3X3, 
  Square,
  Circle,
  Triangle,
  Maximize2,
  RotateCw
} from 'lucide-react';

interface ToolbarProps {
  activeTool: string;
  onToolChange: (tool: string) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetView: () => void;
  onFitToScreen: () => void;
  onToggleGrid: () => void;
  gridEnabled: boolean;
}

const Toolbar: React.FC<ToolbarProps> = ({
  activeTool,
  onToolChange,
  onZoomIn,
  onZoomOut,
  onResetView,
  onFitToScreen,
  onToggleGrid,
  gridEnabled,
}) => {
  const tools = [
    { id: 'select', icon: MousePointer, label: 'Select' },
    { id: 'pan', icon: Move, label: 'Pan' },
    { id: 'measure', icon: Ruler, label: 'Linear Measure' },
    { id: 'radius', icon: Circle, label: 'Radius Measure' },
    { id: 'diameter', icon: Circle, label: 'Diameter Measure' },
    { id: 'angle', icon: Triangle, label: 'Angle Measure' },
  ];

  const ToolButton: React.FC<{ 
    isActive?: boolean; 
    onClick: () => void; 
    icon: React.ComponentType<any>; 
    label: string;
    className?: string;
  }> = ({ isActive, onClick, icon: Icon, label, className = '' }) => (
    <button
      onClick={onClick}
      className={`
        relative p-3 rounded-lg transition-all duration-200 group
        ${isActive 
          ? 'bg-blue-600 text-white shadow-lg' 
          : 'bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white'
        }
        ${className}
      `}
      title={label}
    >
      <Icon className="w-5 h-5" />
      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-slate-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-50">
        {label}
      </div>
    </button>
  );

  return (
    <div className="bg-slate-800 border-b border-slate-700 px-6 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {/* Drawing Tools */}
          <div className="flex items-center space-x-1 bg-slate-700 rounded-lg p-1">
            {tools.map(tool => (
              <ToolButton
                key={tool.id}
                isActive={activeTool === tool.id}
                onClick={() => onToolChange(tool.id)}
                icon={tool.icon}
                label={tool.label}
              />
            ))}
          </div>

          <div className="w-px h-8 bg-slate-600" />

          {/* View Controls */}
          <div className="flex items-center space-x-1">
            <ToolButton
              onClick={onZoomIn}
              icon={ZoomIn}
              label="Zoom In"
            />
            <ToolButton
              onClick={onZoomOut}
              icon={ZoomOut}
              label="Zoom Out"
            />
            <ToolButton
              onClick={onFitToScreen}
              icon={Maximize2}
              label="Fit to Screen"
            />
            <ToolButton
              onClick={onResetView}
              icon={RotateCcw}
              label="Reset View"
            />
          </div>

          <div className="w-px h-8 bg-slate-600" />

          {/* Display Options */}
          <div className="flex items-center space-x-1">
            <ToolButton
              isActive={gridEnabled}
              onClick={onToggleGrid}
              icon={Grid3X3}
              label="Toggle Grid"
            />
          </div>
        </div>

        {/* Right side controls */}
        <div className="flex items-center space-x-2">
          <div className="text-sm text-slate-400 hidden md:block">
            Mouse wheel: Zoom • Touch: Pinch to zoom • Right-click: Pan
          </div>
          <div className="text-sm text-slate-400 md:hidden">
            Pinch to zoom • Two fingers to pan
          </div>
        </div>
      </div>
    </div>
  );
};

export default Toolbar;