import React, { useRef, useEffect, useState, useCallback } from 'react';
import { DrawingState, Measurement, Point } from '../App';

interface DrawingCanvasProps {
  file: File;
  drawingState: DrawingState;
  selectedMeasurement: Measurement | null;
  onMeasurementAdd: (measurement: Measurement) => void;
  onMeasurementSelect: (measurement: Measurement | null) => void;
  onDrawingStateUpdate: (updates: Partial<DrawingState>) => void;
}

const DrawingCanvas: React.FC<DrawingCanvasProps> = ({
  file,
  drawingState,
  selectedMeasurement,
  onMeasurementAdd,
  onMeasurementSelect,
  onDrawingStateUpdate,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPanning, setIsPanning] = useState(false);
  const [isDrawingMeasurement, setIsDrawingMeasurement] = useState(false);
  const [measurementPoints, setMeasurementPoints] = useState<Point[]>([]);
  const [mousePosition, setMousePosition] = useState<Point>({ x: 0, y: 0 });
  const [lastPanPoint, setLastPanPoint] = useState<Point>({ x: 0, y: 0 });
  const [touchStartDistance, setTouchStartDistance] = useState<number>(0);
  const [lastTouchCenter, setLastTouchCenter] = useState<Point>({ x: 0, y: 0 });

  // Enhanced sample drawing elements with circles and arcs
  const sampleDrawingElements = [
    { type: 'line', points: [{ x: 100, y: 100 }, { x: 300, y: 100 }] },
    { type: 'line', points: [{ x: 300, y: 100 }, { x: 300, y: 200 }] },
    { type: 'line', points: [{ x: 300, y: 200 }, { x: 100, y: 200 }] },
    { type: 'line', points: [{ x: 100, y: 200 }, { x: 100, y: 100 }] },
    { type: 'circle', center: { x: 200, y: 150 }, radius: 30 },
    { type: 'arc', center: { x: 400, y: 150 }, radius: 50, startAngle: 0, endAngle: Math.PI },
    { type: 'circle', center: { x: 500, y: 100 }, radius: 25 },
    { type: 'line', points: [{ x: 400, y: 300 }, { x: 600, y: 250 }] },
    { type: 'arc', center: { x: 150, y: 300 }, radius: 40, startAngle: Math.PI/4, endAngle: 3*Math.PI/4 }
  ];

  const drawGrid = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
    if (!drawingState.grid) return;

    ctx.save();
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 0.5;

    const gridSize = 20 * drawingState.zoom;
    const offsetX = drawingState.pan.x % gridSize;
    const offsetY = drawingState.pan.y % gridSize;

    // Vertical lines
    for (let x = offsetX; x < canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }

    // Horizontal lines
    for (let y = offsetY; y < canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    ctx.restore();
  };

  const drawElements = (ctx: CanvasRenderingContext2D) => {
    ctx.save();
    ctx.translate(drawingState.pan.x, drawingState.pan.y);
    ctx.scale(drawingState.zoom, drawingState.zoom);
    ctx.rotate(drawingState.rotation);

    ctx.strokeStyle = '#E5E7EB';
    ctx.lineWidth = 2 / drawingState.zoom;

    sampleDrawingElements.forEach(element => {
      ctx.beginPath();
      if (element.type === 'line') {
        ctx.moveTo(element.points[0].x, element.points[0].y);
        ctx.lineTo(element.points[1].x, element.points[1].y);
      } else if (element.type === 'circle') {
        ctx.arc(element.center.x, element.center.y, element.radius, 0, 2 * Math.PI);
      } else if (element.type === 'arc') {
        ctx.arc(element.center.x, element.center.y, element.radius, element.startAngle, element.endAngle);
      }
      ctx.stroke();
    });

    ctx.restore();
  };

  const drawMeasurements = (ctx: CanvasRenderingContext2D) => {
    ctx.save();
    ctx.translate(drawingState.pan.x, drawingState.pan.y);
    ctx.scale(drawingState.zoom, drawingState.zoom);

    drawingState.measurements.forEach(measurement => {
      const isSelected = selectedMeasurement?.id === measurement.id;
      ctx.strokeStyle = isSelected ? '#F97316' : measurement.color;
      ctx.fillStyle = isSelected ? '#F97316' : measurement.color;
      ctx.lineWidth = 2 / drawingState.zoom;

      if (measurement.type === 'linear' && measurement.points.length >= 2) {
        const [start, end] = measurement.points;
        
        // Draw measurement line
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.stroke();

        // Draw end markers
        const markerSize = 8 / drawingState.zoom;
        ctx.fillRect(start.x - markerSize/2, start.y - markerSize/2, markerSize, markerSize);
        ctx.fillRect(end.x - markerSize/2, end.y - markerSize/2, markerSize, markerSize);

        // Draw dimension text
        const midX = (start.x + end.x) / 2;
        const midY = (start.y + end.y) / 2;
        ctx.font = `${14 / drawingState.zoom}px sans-serif`;
        ctx.fillText(`${measurement.value.toFixed(2)} ${measurement.unit}`, midX + 10, midY - 10);
      } else if ((measurement.type === 'radius' || measurement.type === 'diameter') && measurement.center && measurement.radius) {
        // Draw radius/diameter measurement
        const radiusPoint = {
          x: measurement.center.x + measurement.radius,
          y: measurement.center.y
        };

        // Draw center point
        const centerSize = 6 / drawingState.zoom;
        ctx.fillRect(measurement.center.x - centerSize/2, measurement.center.y - centerSize/2, centerSize, centerSize);

        // Draw radius line
        ctx.beginPath();
        ctx.moveTo(measurement.center.x, measurement.center.y);
        ctx.lineTo(radiusPoint.x, radiusPoint.y);
        ctx.stroke();

        // Draw radius point
        const markerSize = 8 / drawingState.zoom;
        ctx.fillRect(radiusPoint.x - markerSize/2, radiusPoint.y - markerSize/2, markerSize, markerSize);

        // Draw text
        ctx.font = `${14 / drawingState.zoom}px sans-serif`;
        const label = measurement.type === 'radius' ? 'R' : 'Ø';
        ctx.fillText(`${label}${measurement.value.toFixed(2)} ${measurement.unit}`, radiusPoint.x + 10, radiusPoint.y - 10);
      } else if (measurement.type === 'angular' && measurement.points.length >= 3) {
        const [p1, vertex, p2] = measurement.points;
        
        // Draw angle lines
        ctx.beginPath();
        ctx.moveTo(vertex.x, vertex.y);
        ctx.lineTo(p1.x, p1.y);
        ctx.moveTo(vertex.x, vertex.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();

        // Draw angle arc
        const angle1 = Math.atan2(p1.y - vertex.y, p1.x - vertex.x);
        const angle2 = Math.atan2(p2.y - vertex.y, p2.x - vertex.x);
        const arcRadius = 30 / drawingState.zoom;

        ctx.beginPath();
        ctx.arc(vertex.x, vertex.y, arcRadius, angle1, angle2);
        ctx.stroke();

        // Draw angle text
        const midAngle = (angle1 + angle2) / 2;
        const textX = vertex.x + Math.cos(midAngle) * (arcRadius + 20 / drawingState.zoom);
        const textY = vertex.y + Math.sin(midAngle) * (arcRadius + 20 / drawingState.zoom);
        
        ctx.font = `${14 / drawingState.zoom}px sans-serif`;
        ctx.fillText(`${measurement.value.toFixed(1)}°`, textX, textY);

        // Draw vertex marker
        const markerSize = 8 / drawingState.zoom;
        ctx.fillRect(vertex.x - markerSize/2, vertex.y - markerSize/2, markerSize, markerSize);
      }
    });

    // Draw current measurement being drawn
    if (isDrawingMeasurement && measurementPoints.length > 0) {
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 2 / drawingState.zoom;
      
      const worldMouse = screenToWorld(mousePosition);
      
      if (drawingState.activeTool === 'measure') {
        ctx.beginPath();
        ctx.moveTo(measurementPoints[0].x, measurementPoints[0].y);
        ctx.lineTo(worldMouse.x, worldMouse.y);
        ctx.stroke();
      } else if (drawingState.activeTool === 'angle' && measurementPoints.length >= 2) {
        const [p1, vertex] = measurementPoints;
        ctx.beginPath();
        ctx.moveTo(vertex.x, vertex.y);
        ctx.lineTo(p1.x, p1.y);
        ctx.moveTo(vertex.x, vertex.y);
        ctx.lineTo(worldMouse.x, worldMouse.y);
        ctx.stroke();
      }

      // Draw start markers
      const markerSize = 8 / drawingState.zoom;
      ctx.fillStyle = '#3B82F6';
      measurementPoints.forEach(point => {
        ctx.fillRect(point.x - markerSize/2, point.y - markerSize/2, markerSize, markerSize);
      });
    }

    ctx.restore();
  };

  const screenToWorld = (screenPoint: Point): Point => {
    return {
      x: (screenPoint.x - drawingState.pan.x) / drawingState.zoom,
      y: (screenPoint.y - drawingState.pan.y) / drawingState.zoom
    };
  };

  const worldToScreen = (worldPoint: Point): Point => {
    return {
      x: worldPoint.x * drawingState.zoom + drawingState.pan.x,
      y: worldPoint.y * drawingState.zoom + drawingState.pan.y
    };
  };

  const calculateDistance = (p1: Point, p2: Point): number => {
    return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
  };

  const calculateAngle = (p1: Point, vertex: Point, p2: Point): number => {
    const angle1 = Math.atan2(p1.y - vertex.y, p1.x - vertex.x);
    const angle2 = Math.atan2(p2.y - vertex.y, p2.x - vertex.x);
    let angle = Math.abs(angle2 - angle1) * (180 / Math.PI);
    return angle > 180 ? 360 - angle : angle;
  };

  const findNearestCircle = (point: Point): { center: Point; radius: number } | null => {
    const threshold = 20 / drawingState.zoom;
    
    for (const element of sampleDrawingElements) {
      if (element.type === 'circle') {
        const distance = calculateDistance(point, element.center);
        if (Math.abs(distance - element.radius) < threshold) {
          return { center: element.center, radius: element.radius };
        }
      } else if (element.type === 'arc') {
        const distance = calculateDistance(point, element.center);
        if (Math.abs(distance - element.radius) < threshold) {
          return { center: element.center, radius: element.radius };
        }
      }
    }
    return null;
  };

  const getTouchDistance = (touches: TouchList): number => {
    if (touches.length < 2) return 0;
    const touch1 = touches[0];
    const touch2 = touches[1];
    return Math.sqrt(
      Math.pow(touch2.clientX - touch1.clientX, 2) + 
      Math.pow(touch2.clientY - touch1.clientY, 2)
    );
  };

  const getTouchCenter = (touches: TouchList): Point => {
    if (touches.length === 1) {
      return { x: touches[0].clientX, y: touches[0].clientY };
    }
    const touch1 = touches[0];
    const touch2 = touches[1];
    return {
      x: (touch1.clientX + touch2.clientX) / 2,
      y: (touch1.clientY + touch2.clientY) / 2
    };
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    drawGrid(ctx, canvas);

    // Draw drawing elements
    drawElements(ctx);

    // Draw measurements
    drawMeasurements(ctx);
  }, [drawingState, selectedMeasurement, isDrawingMeasurement, measurementPoints, mousePosition]);

  const handleMouseDown = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const point = { x: e.clientX - rect.left, y: e.clientY - rect.top };

    if (drawingState.activeTool === 'pan') {
      setIsPanning(true);
      setLastPanPoint(point);
    } else if (drawingState.activeTool === 'measure') {
      if (!isDrawingMeasurement) {
        setIsDrawingMeasurement(true);
        setMeasurementPoints([screenToWorld(point)]);
      } else {
        const worldPoint = screenToWorld(point);
        const newMeasurement: Measurement = {
          id: Date.now().toString(),
          type: 'linear',
          points: [measurementPoints[0], worldPoint],
          value: calculateDistance(measurementPoints[0], worldPoint),
          unit: 'mm',
          color: '#3B82F6'
        };
        onMeasurementAdd(newMeasurement);
        setIsDrawingMeasurement(false);
        setMeasurementPoints([]);
      }
    } else if (drawingState.activeTool === 'radius' || drawingState.activeTool === 'diameter') {
      const worldPoint = screenToWorld(point);
      const circle = findNearestCircle(worldPoint);
      
      if (circle) {
        const value = drawingState.activeTool === 'radius' ? circle.radius : circle.radius * 2;
        const newMeasurement: Measurement = {
          id: Date.now().toString(),
          type: drawingState.activeTool,
          points: [],
          value: value,
          unit: 'mm',
          color: '#10B981',
          center: circle.center,
          radius: circle.radius
        };
        onMeasurementAdd(newMeasurement);
      }
    } else if (drawingState.activeTool === 'angle') {
      const worldPoint = screenToWorld(point);
      
      if (!isDrawingMeasurement) {
        setIsDrawingMeasurement(true);
        setMeasurementPoints([worldPoint]);
      } else if (measurementPoints.length === 1) {
        setMeasurementPoints([...measurementPoints, worldPoint]);
      } else if (measurementPoints.length === 2) {
        const [p1, vertex] = measurementPoints;
        const angle = calculateAngle(p1, vertex, worldPoint);
        
        const newMeasurement: Measurement = {
          id: Date.now().toString(),
          type: 'angular',
          points: [p1, vertex, worldPoint],
          value: angle,
          unit: '°',
          color: '#F59E0B'
        };
        onMeasurementAdd(newMeasurement);
        setIsDrawingMeasurement(false);
        setMeasurementPoints([]);
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const point = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    setMousePosition(point);

    if (isPanning) {
      const deltaX = point.x - lastPanPoint.x;
      const deltaY = point.y - lastPanPoint.y;
      
      onDrawingStateUpdate({
        pan: {
          x: drawingState.pan.x + deltaX,
          y: drawingState.pan.y + deltaY
        }
      });
      
      setLastPanPoint(point);
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    const newZoom = Math.min(Math.max(drawingState.zoom * zoomFactor, 0.1), 10);

    // Zoom towards mouse position
    const zoomRatio = newZoom / drawingState.zoom;
    const newPanX = mouseX - (mouseX - drawingState.pan.x) * zoomRatio;
    const newPanY = mouseY - (mouseY - drawingState.pan.y) * zoomRatio;

    onDrawingStateUpdate({
      zoom: newZoom,
      pan: { x: newPanX, y: newPanY }
    });
  };

  // Touch event handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    if (e.touches.length === 1) {
      // Single touch - treat as mouse down
      const touch = e.touches[0];
      const point = { x: touch.clientX - rect.left, y: touch.clientY - rect.top };
      handleMouseDown({ clientX: touch.clientX, clientY: touch.clientY } as any);
    } else if (e.touches.length === 2) {
      // Two finger touch - prepare for zoom/pan
      setTouchStartDistance(getTouchDistance(e.touches));
      setLastTouchCenter(getTouchCenter(e.touches));
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    e.preventDefault();
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    if (e.touches.length === 1) {
      // Single touch - treat as mouse move
      const touch = e.touches[0];
      const point = { x: touch.clientX - rect.left, y: touch.clientY - rect.top };
      setMousePosition(point);

      if (isPanning) {
        const deltaX = point.x - lastPanPoint.x;
        const deltaY = point.y - lastPanPoint.y;
        
        onDrawingStateUpdate({
          pan: {
            x: drawingState.pan.x + deltaX,
            y: drawingState.pan.y + deltaY
          }
        });
        
        setLastPanPoint(point);
      }
    } else if (e.touches.length === 2) {
      // Two finger touch - zoom and pan
      const currentDistance = getTouchDistance(e.touches);
      const currentCenter = getTouchCenter(e.touches);

      if (touchStartDistance > 0) {
        // Zoom
        const zoomFactor = currentDistance / touchStartDistance;
        const newZoom = Math.min(Math.max(drawingState.zoom * zoomFactor, 0.1), 10);

        // Pan
        const deltaX = currentCenter.x - lastTouchCenter.x;
        const deltaY = currentCenter.y - lastTouchCenter.y;

        onDrawingStateUpdate({
          zoom: newZoom,
          pan: {
            x: drawingState.pan.x + deltaX,
            y: drawingState.pan.y + deltaY
          }
        });

        setTouchStartDistance(currentDistance);
        setLastTouchCenter(currentCenter);
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    
    if (e.touches.length === 0) {
      setIsPanning(false);
      setTouchStartDistance(0);
    } else if (e.touches.length === 1) {
      // Reset for single touch
      setTouchStartDistance(0);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
      draw();
    };

    const resizeObserver = new ResizeObserver(resizeCanvas);
    resizeObserver.observe(canvas);
    resizeCanvas();

    return () => resizeObserver.disconnect();
  }, [draw]);

  useEffect(() => {
    draw();
  }, [draw]);

  const getToolInstructions = () => {
    switch (drawingState.activeTool) {
      case 'measure':
        return isDrawingMeasurement ? 'Click to finish linear measurement' : 'Click to start linear measurement';
      case 'radius':
        return 'Click on a circle or arc to measure radius';
      case 'diameter':
        return 'Click on a circle or arc to measure diameter';
      case 'angle':
        if (!isDrawingMeasurement) return 'Click first point for angle measurement';
        if (measurementPoints.length === 1) return 'Click vertex point';
        return 'Click third point to complete angle';
      case 'pan':
        return 'Click and drag to pan the view';
      default:
        return 'Select a tool to start measuring';
    }
  };

  return (
    <div className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-crosshair touch-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      />
      
      {/* File info overlay */}
      <div className="absolute top-4 left-4 bg-slate-800/90 backdrop-blur-sm rounded-lg px-4 py-2">
        <div className="text-sm text-white font-medium">{file.name}</div>
        <div className="text-xs text-slate-400">
          {(file.size / 1024 / 1024).toFixed(1)} MB • {file.type || 'CAD Drawing'}
        </div>
      </div>

      {/* Tool status */}
      <div className="absolute top-4 right-4 bg-slate-800/90 backdrop-blur-sm rounded-lg px-4 py-2 max-w-xs">
        <div className="text-sm text-white capitalize">{drawingState.activeTool} Tool</div>
        <div className="text-xs text-blue-400">{getToolInstructions()}</div>
      </div>

      {/* Zoom controls for mobile */}
      <div className="absolute bottom-4 right-4 flex flex-col space-y-2 md:hidden">
        <button
          onClick={() => onDrawingStateUpdate({ zoom: Math.min(drawingState.zoom * 1.2, 10) })}
          className="w-12 h-12 bg-slate-800/90 backdrop-blur-sm rounded-lg flex items-center justify-center text-white hover:bg-slate-700 transition-colors"
        >
          +
        </button>
        <button
          onClick={() => onDrawingStateUpdate({ zoom: Math.max(drawingState.zoom / 1.2, 0.1) })}
          className="w-12 h-12 bg-slate-800/90 backdrop-blur-sm rounded-lg flex items-center justify-center text-white hover:bg-slate-700 transition-colors"
        >
          -
        </button>
      </div>
    </div>
  );
};

export default DrawingCanvas;