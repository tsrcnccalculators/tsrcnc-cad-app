import React from 'react';
import { ZoomIn, MapPin, FileText } from 'lucide-react';

interface StatusBarProps {
  zoom: number;
  coordinates: { x: number; y: number };
  units: string;
  fileName?: string;
}

const StatusBar: React.FC<StatusBarProps> = ({ zoom, coordinates, units, fileName }) => {
  return (
    <div className="bg-slate-800 border-t border-slate-700 px-6 py-2 flex items-center justify-between text-sm">
      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-2 text-slate-300">
          <ZoomIn className="w-4 h-4" />
          <span>{(zoom * 100).toFixed(0)}%</span>
        </div>
        
        <div className="flex items-center space-x-2 text-slate-300">
          <MapPin className="w-4 h-4" />
          <span className="font-mono">
            X: {coordinates.x.toFixed(2)} {units} | Y: {coordinates.y.toFixed(2)} {units}
          </span>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {fileName && (
          <div className="flex items-center space-x-2 text-slate-400">
            <FileText className="w-4 h-4" />
            <span>{fileName}</span>
          </div>
        )}
        
        <div className="text-slate-500">
          Ready
        </div>
      </div>
    </div>
  );
};

export default StatusBar;