import React from 'react';
import { Ruler, Trash2, Eye, EyeOff, Layers, Hash, Circle, Triangle } from 'lucide-react';
import { Measurement } from '../App';

interface PropertiesPanelProps {
  measurements: Measurement[];
  selectedMeasurement: Measurement | null;
  layers: string[];
  onMeasurementSelect: (measurement: Measurement | null) => void;
  onMeasurementRemove: (id: string) => void;
}

const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  measurements,
  selectedMeasurement,
  layers,
  onMeasurementSelect,
  onMeasurementRemove,
}) => {
  const getMeasurementIcon = (type: string) => {
    switch (type) {
      case 'linear':
        return <Ruler className="w-4 h-4" />;
      case 'radius':
      case 'diameter':
        return <Circle className="w-4 h-4" />;
      case 'angular':
        return <Triangle className="w-4 h-4" />;
      default:
        return <Ruler className="w-4 h-4" />;
    }
  };

  const getMeasurementLabel = (measurement: Measurement, index: number) => {
    switch (measurement.type) {
      case 'linear':
        return `Linear ${index + 1}`;
      case 'radius':
        return `Radius ${index + 1}`;
      case 'diameter':
        return `Diameter ${index + 1}`;
      case 'angular':
        return `Angle ${index + 1}`;
      default:
        return `Measurement ${index + 1}`;
    }
  };

  const formatValue = (measurement: Measurement) => {
    if (measurement.type === 'angular') {
      return `${measurement.value.toFixed(1)}°`;
    }
    return `${measurement.value.toFixed(2)} ${measurement.unit}`;
  };

  return (
    <div className="w-80 bg-slate-800 border-l border-slate-700 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-slate-700">
        <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
          <Hash className="w-5 h-5" />
          <span>Properties</span>
        </h3>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Layers Section */}
        <div className="p-4 border-b border-slate-700">
          <h4 className="text-sm font-semibold text-slate-300 mb-3 flex items-center space-x-2">
            <Layers className="w-4 h-4" />
            <span>Layers</span>
          </h4>
          <div className="space-y-2">
            {layers.map((layer, index) => (
              <div key={index} className="flex items-center justify-between p-2 bg-slate-700 rounded-lg">
                <span className="text-sm text-white">{layer}</span>
                <button className="text-slate-400 hover:text-white transition-colors">
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Measurements Section */}
        <div className="p-4">
          <h4 className="text-sm font-semibold text-slate-300 mb-3 flex items-center space-x-2">
            <Ruler className="w-4 h-4" />
            <span>Measurements ({measurements.length})</span>
          </h4>
          
          {measurements.length === 0 ? (
            <div className="text-center py-8">
              <Ruler className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400 text-sm">No measurements yet</p>
              <p className="text-slate-500 text-xs mt-1">Use measurement tools to add dimensions</p>
            </div>
          ) : (
            <div className="space-y-2">
              {measurements.map((measurement, index) => (
                <div
                  key={measurement.id}
                  className={`
                    p-3 rounded-lg border transition-all duration-200 cursor-pointer
                    ${selectedMeasurement?.id === measurement.id
                      ? 'bg-orange-500/10 border-orange-500/50'
                      : 'bg-slate-700 border-slate-600 hover:border-slate-500'
                    }
                  `}
                  onClick={() => onMeasurementSelect(measurement)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {getMeasurementIcon(measurement.type)}
                      <span className="text-sm font-medium text-white">
                        {getMeasurementLabel(measurement, index)}
                      </span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onMeasurementRemove(measurement.id);
                      }}
                      className="text-slate-400 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Type:</span>
                      <span className="text-slate-300 capitalize">{measurement.type}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Value:</span>
                      <span className="text-slate-300 font-mono">
                        {formatValue(measurement)}
                      </span>
                    </div>
                    
                    {measurement.type === 'linear' && measurement.points.length >= 2 && (
                      <>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Start:</span>
                          <span className="text-slate-300 font-mono">
                            ({measurement.points[0].x.toFixed(1)}, {measurement.points[0].y.toFixed(1)})
                          </span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">End:</span>
                          <span className="text-slate-300 font-mono">
                            ({measurement.points[1].x.toFixed(1)}, {measurement.points[1].y.toFixed(1)})
                          </span>
                        </div>
                      </>
                    )}
                    
                    {(measurement.type === 'radius' || measurement.type === 'diameter') && measurement.center && (
                      <>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Center:</span>
                          <span className="text-slate-300 font-mono">
                            ({measurement.center.x.toFixed(1)}, {measurement.center.y.toFixed(1)})
                          </span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Radius:</span>
                          <span className="text-slate-300 font-mono">
                            {measurement.radius?.toFixed(2)} mm
                          </span>
                        </div>
                      </>
                    )}
                    
                    {measurement.type === 'angular' && measurement.points.length >= 3 && (
                      <>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Vertex:</span>
                          <span className="text-slate-300 font-mono">
                            ({measurement.points[1].x.toFixed(1)}, {measurement.points[1].y.toFixed(1)})
                          </span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Angle:</span>
                          <span className="text-slate-300 font-mono">
                            {measurement.value.toFixed(1)}°
                          </span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Selected Measurement Details */}
        {selectedMeasurement && (
          <div className="p-4 border-t border-slate-700">
            <h4 className="text-sm font-semibold text-slate-300 mb-3">Selection Details</h4>
            <div className="bg-slate-700 rounded-lg p-3 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">ID:</span>
                <span className="text-slate-300 font-mono">{selectedMeasurement.id}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Color:</span>
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-4 h-4 rounded border border-slate-600"
                    style={{ backgroundColor: selectedMeasurement.color }}
                  />
                  <span className="text-slate-300 font-mono">{selectedMeasurement.color}</span>
                </div>
              </div>
              {selectedMeasurement.type === 'angular' && (
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Unit:</span>
                  <span className="text-slate-300">Degrees (°)</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertiesPanel;