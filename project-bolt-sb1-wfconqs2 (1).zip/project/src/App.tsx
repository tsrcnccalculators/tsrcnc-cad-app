import React, { useState, useRef, useEffect } from 'react';
import { Upload, ZoomIn, ZoomOut, Move, Ruler, RotateCcw, Layers, Settings, Grid, Square } from 'lucide-react';
import FileUploadArea from './components/FileUploadArea';
import DrawingCanvas from './components/DrawingCanvas';
import Toolbar from './components/Toolbar';
import PropertiesPanel from './components/PropertiesPanel';
import StatusBar from './components/StatusBar';

export interface Point {
  x: number;
  y: number;
}

export interface Measurement {
  id: string;
  type: 'linear' | 'angular' | 'radius' | 'diameter' | 'area';
  points: Point[];
  value: number;
  unit: string;
  color: string;
  center?: Point;
  radius?: number;
}

export interface DrawingState {
  zoom: number;
  pan: Point;
  rotation: number;
  grid: boolean;
  layers: string[];
  activeTool: string;
  measurements: Measurement[];
}

function App() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [drawingState, setDrawingState] = useState<DrawingState>({
    zoom: 1,
    pan: { x: 0, y: 0 },
    rotation: 0,
    grid: true,
    layers: ['Layer 1', 'Dimensions', 'Text'],
    activeTool: 'select',
    measurements: []
  });
  const [selectedMeasurement, setSelectedMeasurement] = useState<Measurement | null>(null);
  const [showPropertiesPanel, setShowPropertiesPanel] = useState(true);

  const handleFileUpload = (file: File) => {
    setUploadedFile(file);
  };

  const handleToolChange = (tool: string) => {
    setDrawingState(prev => ({ ...prev, activeTool: tool }));
  };

  const handleZoomIn = () => {
    setDrawingState(prev => ({ 
      ...prev, 
      zoom: Math.min(prev.zoom * 1.2, 10) 
    }));
  };

  const handleZoomOut = () => {
    setDrawingState(prev => ({ 
      ...prev, 
      zoom: Math.max(prev.zoom / 1.2, 0.1) 
    }));
  };

  const handleResetView = () => {
    setDrawingState(prev => ({
      ...prev,
      zoom: 1,
      pan: { x: 0, y: 0 },
      rotation: 0
    }));
  };

  const handleFitToScreen = () => {
    // This will be implemented in the DrawingCanvas component
    setDrawingState(prev => ({
      ...prev,
      zoom: 0.8, // Fit with some padding
      pan: { x: 0, y: 0 }
    }));
  };

  const toggleGrid = () => {
    setDrawingState(prev => ({ ...prev, grid: !prev.grid }));
  };

  const addMeasurement = (measurement: Measurement) => {
    setDrawingState(prev => ({
      ...prev,
      measurements: [...prev.measurements, measurement]
    }));
  };

  const removeMeasurement = (id: string) => {
    setDrawingState(prev => ({
      ...prev,
      measurements: prev.measurements.filter(m => m.id !== id)
    }));
    if (selectedMeasurement?.id === id) {
      setSelectedMeasurement(null);
    }
  };

  const updateDrawingState = (updates: Partial<DrawingState>) => {
    setDrawingState(prev => ({ ...prev, ...updates }));
  };

  return (
    <div className="h-screen bg-slate-900 text-gray-100 flex flex-col overflow-hidden">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Square className="w-8 h-8 text-blue-500" />
          <div>
            <h1 className="text-xl font-bold text-white">CAD Drawing Viewer</h1>
            <p className="text-sm text-slate-400">Professional Drawing Analysis Tool</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowPropertiesPanel(!showPropertiesPanel)}
            className="px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors duration-200 flex items-center space-x-2"
          >
            <Settings className="w-4 h-4" />
            <span className="text-sm">Properties</span>
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Content Area */}
        <div className="flex-1 flex flex-col">
          {/* Toolbar */}
          <Toolbar
            activeTool={drawingState.activeTool}
            onToolChange={handleToolChange}
            onZoomIn={handleZoomIn}
            onZoomOut={handleZoomOut}
            onResetView={handleResetView}
            onFitToScreen={handleFitToScreen}
            onToggleGrid={toggleGrid}
            gridEnabled={drawingState.grid}
          />

          {/* Drawing Area */}
          <div className="flex-1 relative bg-slate-800">
            {!uploadedFile ? (
              <FileUploadArea onFileUpload={handleFileUpload} />
            ) : (
              <DrawingCanvas
                file={uploadedFile}
                drawingState={drawingState}
                selectedMeasurement={selectedMeasurement}
                onMeasurementAdd={addMeasurement}
                onMeasurementSelect={setSelectedMeasurement}
                onDrawingStateUpdate={updateDrawingState}
              />
            )}
          </div>

          {/* Status Bar */}
          <StatusBar
            zoom={drawingState.zoom}
            coordinates={{ x: 0, y: 0 }}
            units="mm"
            fileName={uploadedFile?.name}
          />
        </div>

        {/* Properties Panel */}
        {showPropertiesPanel && (
          <PropertiesPanel
            measurements={drawingState.measurements}
            selectedMeasurement={selectedMeasurement}
            layers={drawingState.layers}
            onMeasurementSelect={setSelectedMeasurement}
            onMeasurementRemove={removeMeasurement}
          />
        )}
      </div>
    </div>
  );
}

export default App;